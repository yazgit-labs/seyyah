#!/bin/bash
sleep 2 
xterm -e "roslaunch ika_navigation amcl_demo.launch map_file:=/home/$(whoami)/catkin_ws/src/hector/hector_ika/maps/map.yaml" &
